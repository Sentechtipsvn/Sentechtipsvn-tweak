# SenAI Lab 1.0-alpha.2
© Sentechtipsvn — kiểm thử DeepSeek Native trên iPhone 7 Plus / iOS 15.8.8

**Trạng thái:** mã nguồn Objective-C/UIKit đã được biên dịch thành object ARM64 với khai báo tương thích tối thiểu. Chưa liên kết executable iOS, chưa ký, chưa tạo DEB có thể cài, chưa chạy trên thiết bị. Môi trường Linux không có Apple SDK, ldid; ld64.lld hiện có từ chối liên kết platform iOS. Không được cài object `.o` bằng Filza.

## Tính năng bản Lab

- 11 bài kiểm thử: model, số dư, streaming, dịch, viết lại, Vision, ASR, TTS, tool calls (chỉ xem trước), Clipboard, Pro.
- Chọn ảnh từ thư viện (bao gồm ảnh chụp màn hình), thu WAV PCM tối đa 30 giây hoặc dùng dữ liệu mẫu.
- Chạy từng bài hoặc chạy 11 bài tuần tự với mẫu đóng gói; dừng ở lỗi đầu tiên. Chỉ TTS giọng Stella trong bản này.
- Báo HTTP, thời gian, token, chi phí Chat ước lượng cao điểm; không gồm phí ASR/TTS. Kết quả hợp lệ không khẳng định nội dung đúng.
- API Key chỉ giữ trong bộ nhớ phiên; không ghi key vào file, không xuất key hoặc nội dung riêng tư trong báo cáo. Audio thu được lưu tạm để AVAudioRecorder hoạt động rồi xóa khi dừng; nếu app bị kết thúc đột ngột, tệp tạm có thể còn trong thư mục tạm iOS.
- Gửi HTTPS đến api.deepseek.com, từ chối redirect, không tự retry. Mất mạng hoặc hủy yêu cầu vẫn có thể phát sinh phí.
- Không hook SpringBoard, không cần quyền root khi chạy, không thực thi tool call, không can thiệp QuickControl/ShareWifi.
- Native UIKit, màu hệ thống Light/Dark, tiếng Việt. Chưa phải SenAI Tweak 1.0 hoàn chỉnh.

## Build DEB rootless bằng macOS + Theos

1. Cần Mac có Xcode/iPhoneOS SDK tương thích, Theos, ldid, dpkg, xz, GNU make. Cài command line tools nếu cần.
2. Ví dụ khi đã có Homebrew và Xcode:

```sh
brew install ldid dpkg make xz
git clone --recursive https://github.com/theos/theos.git "$HOME/theos"
export THEOS="$HOME/theos"
cd /duong/dan/SenAI-Lab
gmake package FINALPACKAGE=1
```

DEB dự kiến ở `packages/`. `dpkg-deb -I packages/*.deb` phải cho kiến trúc `iphoneos-arm64`; `dpkg-deb -c packages/*.deb` phải có `/var/jb/Applications/SenAILab.app/SenAILab` cùng Info.plist và fixture. Nếu build thất bại, gửi log lỗi thay vì cài gói không hợp lệ. Build rootless dành cho Dopamine, không phải rootful hay RootHide.

## Build trên GitHub Actions (không cần Mac cá nhân)

Tạo hoặc dùng repo riêng cho SenAI Lab, đưa toàn bộ nội dung thư mục này (kể cả `.github/workflows/build-deb.yml`) vào thư mục gốc repo. Mở Actions > **Build SenAI Lab rootless DEB** > Run workflow. Job macos-15 dùng Xcode SDK và Theos để build. Sau khi job thành công, tải artifact `SenAI-Lab-rootless`, giải nén lấy DEB. Chưa chạy workflow trong phiên này; build có thể phát hiện vấn đề SDK hoặc dependency. Không đưa API Key vào repo hoặc GitHub Actions.

## Kiểm thử trên iPhone (sau khi có DEB build thành công)

1. Đảm bảo Dopamine đang jailbreak (rootless). Mở DEB bằng Filza hoặc Sileo, cài gói. Gói dùng uicache để đăng ký icon, không yêu cầu Respring. Nếu không mở được app, gửi lỗi hoặc crash log; không cố sửa hệ thống.
2. Mở SenAI Lab từ màn hình chính, nhập DeepSeek API Key của riêng bạn. Không gửi key cho người khác.
3. Chạy **Danh sách model**, **Kiểm tra số dư**. Nếu lỗi HTTP 401 kiểm tra key, 402 kiểm tra số dư, 429 kiểm tra giới hạn, 5xx kiểm tra máy chủ. Không tự gửi lại.
4. Chạy Hỏi đáp, Vision, ASR, TTS riêng, kiểm tra nội dung thực tế. Vision mặc định có ảnh mẫu; ASR mặc định có WAV mẫu. Bản thu thật và ảnh cá nhân chỉ gửi sau khi xác nhận. Sau đó có thể chạy toàn bộ mẫu một lần nếu muốn.
5. Chọn **Xuất báo cáo kỹ thuật**, sao chép/chia sẻ JSON. Báo cáo chỉ chứa trạng thái, HTTP, thời lượng và thống kê, không chứa key, ảnh, âm thanh hoặc prompt. Nếu cần, gửi ảnh màn hình kết quả sau khi che thông tin riêng tư.
6. Chọn **Xóa API Key và dữ liệu phiên** khi kết thúc; hoặc gỡ app qua Sileo.

## Tài liệu API đối chiếu 24/11/2026
- https://api-docs.deepseek.com/api/create-chat-completion/
- https://api-docs.deepseek.com/guides/vision/
- https://api-docs.deepseek.com/api/asr/
- https://api-docs.deepseek.com/api/tts/
- https://api-docs.deepseek.com/quick_start/pricing/
- https://theos.dev/docs/rootless

## Giới hạn và bước tiếp theo
Bản này là ứng dụng Lab độc lập, chưa có Core service/IPC, Keychain, lịch sử SQLite, ngân sách cứng, Writing Tools hoặc module Control Center. Các mục đó thuộc các giai đoạn sau. Cần build SDK thật, kiểm tra ký app, quyền ảnh/micro và nghiệm thu API trên tài khoản thực tế trước khi port sang Tweak. Không thay đổi bất kỳ dự án hiện hữu nào.
